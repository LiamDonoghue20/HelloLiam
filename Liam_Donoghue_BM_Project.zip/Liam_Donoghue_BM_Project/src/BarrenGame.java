import java.util.ArrayList;
import java.util.Scanner;

public class BarrenGame {
    boolean moving = true;
    boolean creatingCharacter = true;
    boolean newFriend = true;
    ArrayList<Player> players = new ArrayList<>();
    ArrayList<Loot> loot = new ArrayList<>();
    int playerLevel = 1;


//method for creating a new character
    public void characterCustomization(){
        //inputting the new characters various details
            Scanner sca = new Scanner(System.in);
            System.out.println("Welcome to the Barren Moore! Please enter your new hero details");
            System.out.println("Please enter your characters name!");
            String playerName = sca.nextLine();

            System.out.println("Please enter your characters race Human, Elf, Dwarf or Orc");
            String playerRace = sca.nextLine();

            System.out.println("Please enter your characters gender Female, Male or Other");
            String playerGender = sca.nextLine();

            System.out.println("Please enter your characters class Paladin, Warrior, Assassin or Wizard");
            String playerClass = sca.nextLine();

            System.out.println("Would you like your character to wield a Sword, Staff, Mace or Dagger");
            String playerWeapon = sca.nextLine();
        //storing both the character and starter weapon to an array
            players.add(new Player(playerName, playerRace, playerGender, playerClass, playerWeapon, playerLevel));
            loot.add(new Loot("Starter weapon", playerWeapon, 1));
            System.out.println("Your character is as follows: ");
            System.out.println(players.toString());
    };

    public void movement(){
//main menu of the game
        Scanner sca = new Scanner(System.in);
    System.out.println("You are in the middle of a grey misty swamp, please select the directions you wish to move by selecting the first character (N,S,E,W)");
        System.out.println("[N]orth - There is an abandoned castle in the distance to the North");
        System.out.println("[S]outh - You can see mountains on the horizon to the South");
        System.out.println("[E]ast - Farmland and a small town which you came from is visible to the East" );
        System.out.println("[W]est - The mist seems more dense to the West, it is almost impossible to see through it ");
        System.out.println("[L]oot - If you would like to see the weapons you currently have, please press 'L'");
        System.out.println("[C]haracter - If you would like to see your characters info again, please press 'C'");
        String userChoice = sca.nextLine();

        //choosing which method to access based of user choice
        do {
            switch (userChoice.toUpperCase()){
                case "N":
                    north();
                    break;
                case "S":
                    south();
                    break;
                case "E":
                    east();
                    break;
                case "W":
                    west();
                    break;
                case "L":
                    viewLoot();
                    break;
                case "C":
                    System.out.println("Your characters details are as follows:");
                    System.out.println(players.toString());
                    movement();
                default:
                    System.out.println("That is an invalid option, please try again!");
                    movement();
                    break;
            }
        }while(moving = false);
    }

    public void north(){
        boolean north = true;
        Scanner sca = new Scanner(System.in);
        System.out.println("You begin to move North to the abandoned castle");
        System.out.println("Upon entering the castle you are greeted by an old wizard");
        System.out.println("Please select your next action by choosing one of the numbers below");
        System.out.println("1. Ask the wizard for training in magic");
        System.out.println("2. Search the castle for goods to steal");
        System.out.println("3. Ambush the wizard");
        System.out.println("4. Return to the swamp");
        String userChoice = sca.nextLine();
        do {
            switch (userChoice.toUpperCase()){

                case "1":
                    System.out.println("The wizard gladly accepts and spends the whole day teaching you how to cast spells");
                    playerLevel++;

                    System.out.println("Congratulations, you are now level " +playerLevel);
                break;

                case "2":
                    System.out.println("You creep around the castle quietly looking for rare items");
                    System.out.println("You find a shiny new sword for your collection!");
                    String weaponName = "Gold sword";
                    String weaponType = "Sword";
                    int weaponLevel = 5;
                    loot.add(new Loot(weaponName, weaponType, weaponLevel));
                break;

                case "3":
                    System.out.println("You attempt to ambush the wizard!");
                    System.out.println("He tries to fight back but the element of surprise has him defeated");
                    playerLevel++;
                    System.out.println("You are now level " +playerLevel+ ". But at what cost?" );
                break;

                case "4":
                    System.out.println("You decide to travel back to where you came from");
                    movement();
                break;

                default:
                    break;


            }
                        keepPlaying();

        }while(north = false);
    }

    //where the mountains are
    public void south(){
        boolean south;
        Scanner sca = new Scanner(System.in);
        System.out.println("You start to walk into the mountains, watch out for ogres!");
        System.out.println("Shortly after arriving at the mountains, you spot another traveller who has been badly injured after fighting an Ogre");
        System.out.println("Please select your next action by choosing one of the numbers below");
        System.out.println("1. Aid the traveller by providing medical care");
        System.out.println("2. Finish the traveller off and take any weapons they have ");
        System.out.println("3. Search for the Ogre that the traveller had been beaten by for revenge");
        System.out.println("4. Leave the traveller for dead and return to the swamp");
        String userChoice = sca.nextLine();
        do {
            switch(userChoice.toUpperCase()){
                case "1":
                    System.out.println("You aid the traveller. in return they give you their most prized possession, their iron mace! ");
                    System.out.println("Unknown Traveller: Thank you so much! Its not a lot but please take this weapon, its all I can do to thank you!");
                    System.out.println("Unknown Traveller: Be wary of the Ogre! He would of killed me had he not gotten bored of punching me! He lives in a small shack to the north west");
                    boolean newFriend = true;
                    playerLevel++;
                    //need code here to update the player array with the new level
                    String weaponName = "Iron Mace";
                    String weaponType = "Mace";
                    int weaponLevel = 3;
                    //could possibly have code for the player to equip the weapon with the highest level?
                    loot.add(new Loot(weaponName, weaponType, weaponLevel));
                    System.out.println("Congratulations you are now level " +playerLevel+ " and have a 'Iron Mace' in your inventory");
                break;

                case "2":
                    System.out.println("You mercilessly kill the injured traveller and recover the items from their corpse, how could you!");
                    System.out.println("You find a new iron mace to add to your collection");
                    String weaponNameStolen = "Iron Mace";
                    String weaponTypeStolen = "Mace";
                    int weaponLevelStolen = 3;
                    loot.add(new Loot(weaponNameStolen, weaponTypeStolen, weaponLevelStolen));
                break;

                case "3":
                    newFriend = true;
                    System.out.println("After making sure that the traveller is okay, you go further into the mountains to find the ogre");
                    System.out.println("After a short journey you spot a large, terrifying figure in the distance");
                    System.out.println("Ogre: GET OUT OF HERE! YOU DON'T WANT TO END UP LIKE YOUR FRIEND");
                    ogreFight();
                break;

                case "4":
                    System.out.println("Worried that you could be next, you flee back to the swamp");
                    movement();
                break;

                default:
                    break;


            }

        keepPlaying();

        } while (south = false);

    }

    //safe town
    public void east() {
        System.out.println("You decide to turn back and walk to the safe town, coward!");
        boolean east;
        Scanner sca = new Scanner(System.in);

        System.out.println("Whilst travelling back to town, you are ambushed by a group of 3 bandits! They want your money and items!");
        System.out.println("Please select your next action by choosing one of the numbers below");
        System.out.println("1. Surrender and give the bandits the weapons you have in hopes that they will spare your life");
        System.out.println("2. Fight all three of the travellers on your own");
        System.out.println("3. Shout for help");
        System.out.println("4. Out run the bandits back to the swamp");
        String userChoice = sca.nextLine();

        do {

            switch(userChoice.toUpperCase()){
                case "1":
                    System.out.println("You give the traveller all the items you currently have");
                    System.out.println("Bandit leader: We'll let you live... this time");
                    loot.clear();
                break;

                case "2":
                    if (playerLevel > 1) {
                        System.out.println("You are too strong for the bandits! You defeat all 3 easily and find some shabby weapons they are carrying");
                        String weaponName = "Thief's Daggers";
                        String weaponType = "Dagger";
                        int weaponLevel = 2;
                        loot.add(new Loot(weaponName, weaponType, weaponLevel));
                        playerLevel++;
                        System.out.println("Congratulations, you are now level " +playerLevel);
                    } else {
                        System.out.println("You are no match for 3 opponents at once! The travellers beat you up and take your stuff");
                        loot.clear();
                        System.out.println("Too ashamed of your defeat to return home, you wander helplessly back to the swamp");
                        movement(); }
                break;

                case "3":
                    //want to make this the boolean from the south() class, if its true the traveller aided comes to help, if false you are left to be defeated
                    if(newFriend){
                        System.out.println("The traveller you aided in the mountains luckily hears you and rushes to your assistance!");
                        System.out.println("Together you defeat the bandits and recover weapons from their possession");
                        String weaponName = "Thief's Daggers";
                        String weaponType = "Dagger";
                        int weaponLevel = 2;
                        loot.add(new Loot(weaponName, weaponType, weaponLevel));
                        playerLevel++;
                        System.out.println("Congratulations, you are now level "+playerLevel+" and you managed to take " +weaponName+ " from the bandits!");
                    } else if (!newFriend){

                        System.out.println("Nobody hears your call! You are no match for 3 opponents at once! The travellers beat you up and take your stuff");
                        loot.clear();
                        System.out.println("Too ashamed of your defeat to return home, you wander helplessly back to the swamp");
                        movement(); }

                break;

                case "4":
                    System.out.println("Luckily the bandits are slow and you manage to run back to the swamp!");
                    movement();
            }

            keepPlaying();

        }while (east = false);

    }

    public void west(){
        System.out.println("You have decided to keep walking into the dense mist, are you crazy!?");
        boolean west;
        Scanner sca = new Scanner(System.in);
        System.out.println("As you travel through the mist you stumble upon an abandoned shack");
        System.out.println("Inside the shack you find shelves of untouched books about wizardry and treasure chests filled with old weapons");
        System.out.println("With the mist getting worse you need to move quickly and must decide what you must do with this new found building"); //change this
        System.out.println("Please select your next action by choosing one of the numbers below");
        System.out.println("1. Gather as many books as possible");
        System.out.println("2. Gather as many weapons as possible");
        System.out.println("3. Further explore the shack");
        System.out.println("4. Leave the shack and return back to the swamp");
        String userChoice = sca.nextLine();

        do {

            switch(userChoice.toUpperCase()) {

                case "1":
                    System.out.println("You gather as many books as possible to assist with learning new magic spells, your new wisdom has made you grow stronger!");//
                    playerLevel++;
                    playerLevel++;
                    playerLevel++;
                    System.out.println("Your new found wisdom has made you extra powerful! You are now level " +playerLevel);
                break;

                case "2":
                    System.out.println("You rummage through the chests and gather as many weapons that you can carry");
                    loot.add(new Loot("Steel Sword", "Sword", 4));
                    loot.add(new Loot("Brute Axe", "Axe", 8));
                    loot.add(new Loot("Wizard's Staff", "Staff", 15));
                    System.out.println("You add: 'Steel Sword', 'Brute Axe' and 'Wizard's Staff' to your inventory");
                break;

                case "3":
                    System.out.println("You decide to stick around even though the mist is getting worse");
                    System.out.println("As you explore the shack, you hear loud footsteps and grunting coming from one of the rooms");
                    System.out.println("OH NO! ITS AN OGRE!!!!");
                    System.out.println("Ogre: WHAT ARE YOU DOING HERE FILTHY WEAKLING, I WILL CRUSH YOU!");
                    ogreFight();
                break;

                case "4":
                    System.out.println("Scared at thought of who could live in such a place, you return to the swamp");
                    movement();
            }
            keepPlaying();

        } while (west = false);

    }

    public void ogreFight(){

        boolean fightingOgre;
        int ogreHealth;
        ogreHealth = 10;
        int heroHealth;
        heroHealth = 10;
        Scanner sca = new Scanner(System.in);

        System.out.println("Ogre: YOU THINK YOU'RE STRONG ENOUGH TO DEFEAT ME? HAHA");
        System.out.println("The Ogre begins to charge at you!");
        System.out.println("Please select your next action by choosing one of the numbers below");
        System.out.println("1. Swing your weapon ferociously at the ogres head");
        System.out.println("2. Try to use magic spells to defeat the beast");
        System.out.println("3. Run in terror back to the swamp");
        String userChoice = sca.nextLine();


        do {

            switch(userChoice.toUpperCase()) {

                case "1":
                    System.out.println("You smash your weapon in the face of the ugly ogre!");
                    System.out.println("The monster is defeated! And it dropped the rare Staff of Arcane");
                    playerLevel++;
                    loot.add(new Loot("Staff of Arcane", "Staff", 30));
                    System.out.println("Congratulations you are now level "+playerLevel+" and have 'Staff of Arcane' in your inventory");

                break;

                //wanted to make it so that the user would of needed to of done the mage training to the north in order to defeat the ogre by magic
                case "2":
                    if (playerLevel > 3 ){
                        System.out.println("You use a mighty fireball to bast the Ogre in his ugly face!");
                        System.out.println("The monster is defeated! And it dropped the rare Staff of Arcane");
                        playerLevel++;
                        loot.add(new Loot("Staff of Arcane", "Staff", 30));
                        System.out.println("Congratulations you are now level "+playerLevel+" and have 'Staff of Arcane' in your inventory");
                    } else {
                        System.out.println("Your magic is nowhere near strong enough to hurt the beast!");
                        System.out.println("The Ogre picks you up and throws you against the floor!");
                        --heroHealth;
                        System.out.println("You are now at " +heroHealth+"HP");
                        ogreFight();
                    }
                break;

                case "3":
                    System.out.println("In fear for your life, you head back in the direction you came");
                    movement();
                    break;
                default:
                break;
            }

            keepPlaying();

        } while (fightingOgre = false);


    }

    public void keepPlaying (){
        boolean keepPlaying = true;

        do {
            Scanner sca = new Scanner(System.in);
            System.out.println("Would you like to keep exploring the Barren Moore? (Y/N)");
            String anotherOption = sca.nextLine();
            if (anotherOption.equalsIgnoreCase("y")) {
                movement();
            } else if (anotherOption.equalsIgnoreCase("N")) {
                System.out.println("Thank you for exploring the world, your character finished level " + playerLevel + " with these items: " + loot.toString());
            } else {

                System.out.println("That is not a valid choice!");
                keepPlaying();
            }
        } while (keepPlaying);
    }

    public void viewLoot() {
        System.out.println("The weapons that you currently have: ");
        System.out.println(loot.toString());
        movement();

    }


}
