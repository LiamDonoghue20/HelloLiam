public class BarrenMain {

    public static void main(String[] args) {
        BarrenGame barrenGame = new BarrenGame();

        barrenGame.characterCustomization();
        barrenGame.movement();


    }
}
