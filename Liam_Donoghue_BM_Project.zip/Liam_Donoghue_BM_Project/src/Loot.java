public class Loot {

    private String weaponName;
    private String weaponType;
    private int weaponLevel;


    public Loot (String weaponName, String weaponType, int weaponLevel){
        this.weaponName = weaponName;
        this.weaponType = weaponType;
        this.weaponLevel = weaponLevel;
    }

    public String getWeaponName() {
        return weaponName;
    }

    public String getWeaponType() {
        return weaponType;
    }

    public int getWeaponLevel() {
        return weaponLevel;
    }


    public String toString() {
        return " Weapon Name: "+this.weaponName+" Weapon Type: " + this.weaponType + " Weapon Level: " + this.weaponLevel +"\n";
    }
}
