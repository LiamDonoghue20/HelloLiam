public class Player {

    private String playerName;
    private String playerRace;
    private String playerGender;
    private String playerClass;
    private String playerWeapon;
    private int playerLevel;



    public  Player(String playerName, String playerRace, String playerGender, String playerClass, String playerWeapon, int playerLevel) {

        this.playerName = playerName;
        this.playerRace = playerRace;
        this.playerGender = playerGender;
        this.playerClass = playerClass;
        this.playerWeapon = playerWeapon;
        this.playerLevel = playerLevel;

    }

    public String getPlayerClass() {
        return playerClass;
    }

    public String getPlayerRace() {
        return playerRace;
    }

    public String getPlayerGender() {
        return playerGender;
    }

    public String getPlayerName() {
        return playerName;
    }
    public int getPlayerLevel(){
        return playerLevel;
    }

    public String getPlayerWeapon() {
        return playerWeapon;
    }

    public void setPlayerLevel(int playerLevel) {
        this.playerLevel = playerLevel;
    }

    public String toString() {
        return "Name: "+this.playerName+" | Race: " + this.playerRace + " | Gender: " + this.playerGender + " | Class: " + this.playerClass + " | Current Weapon : " +this.playerWeapon+" | Current Level: " + this.playerLevel;
    }
}
